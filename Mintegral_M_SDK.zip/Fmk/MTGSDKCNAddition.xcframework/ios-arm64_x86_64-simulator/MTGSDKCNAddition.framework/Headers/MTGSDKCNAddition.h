//
//  MTGSDKCNAddition.h
//  MTGSDKCNAddition
//
//  Created by Harry on 2022/11/3.
//  Copyright © 2022 Mintegral. All rights reserved.
//


#import <Foundation/Foundation.h>

#define MTGCNAdditionSDKVersion @"7.3.0"


//! Project version number for MTGSDKCNAddition.
FOUNDATION_EXPORT double MTGSDKCNAdditionVersionNumber;

//! Project version string for MTGSDKCNAddition.
FOUNDATION_EXPORT const unsigned char MTGSDKCNAdditionVersionString[];
